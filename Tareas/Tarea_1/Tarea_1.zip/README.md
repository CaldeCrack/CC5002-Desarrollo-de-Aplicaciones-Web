# Tarea 1

## CC5002 - Desarrollo de Aplicaciones Web

### Andrés Calderón Guardia

Todas las imágenes utilizadas son de uso público, algunas las tomé yo mismo, y otras son de amigos que me permitieron usarlas.

Para la realización de esta tarea usé en particular la extensión de live server en vscode como modo de visualización de la página.
