# Tarea 3

## CC5002 - Desarrollo de Aplicaciones Web

### Andrés Calderón Guardia

Para no tener problemas con las rutas de los archivos hay que asegurarse que la terminal desde donde se está ejecutando el archivo `app.py` esté ubicada en la carpeta `app`.

Y otro detalle es que para las estadísticas tuve que usar en origen del `cross_origin` la ruta `http://127.0.0.1`, y de puerto 5000 en el fetch porque al menos en mi pc el puerto que se elige al ejecutar el archivo `app.py` es 5000, esto dado que usando `localhost` me daba error de CORS.
