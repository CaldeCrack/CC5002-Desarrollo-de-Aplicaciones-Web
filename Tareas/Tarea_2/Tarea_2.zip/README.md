# Tarea 2

## CC5002 - Desarrollo de Aplicaciones Web

### Andrés Calderón Guardia

Para no tener problemas con las rutas de los archivos hay que asegurarse que la terminal desde donde se está ejecutando el archivo `app.py` esté ubicada en la carpeta `app`.
